from stepAction import rpaChallengeAutomation


if __name__ == "__main__":
    app = rpaChallengeAutomation()